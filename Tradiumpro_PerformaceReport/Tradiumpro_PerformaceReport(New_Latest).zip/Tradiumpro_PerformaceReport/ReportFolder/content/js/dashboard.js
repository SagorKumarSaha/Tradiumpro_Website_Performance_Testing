/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 38.22933724036887, "KoPercent": 61.77066275963113};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.17683465483064725, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.6181147729891681, 500, 1500, "Security settings page-0"], "isController": false}, {"data": [7.142857142857143E-5, 500, 1500, "Log in page"], "isController": false}, {"data": [0.0, 500, 1500, "Tradiumpro Home Page"], "isController": false}, {"data": [0.08710967250571211, 500, 1500, "Log in page-1"], "isController": false}, {"data": [1.8621973929236498E-4, 500, 1500, "Log in page-2"], "isController": false}, {"data": [0.56502284843869, 500, 1500, "Log in page-0"], "isController": false}, {"data": [0.5686210640608035, 500, 1500, "Tradiumpro Home Page-0"], "isController": false}, {"data": [2.9859659599880563E-4, 500, 1500, "Forgot password page-2"], "isController": false}, {"data": [0.0, 500, 1500, "Tradiumpro Home Page-1"], "isController": false}, {"data": [0.0, 500, 1500, "Tradiumpro Home Page-2"], "isController": false}, {"data": [1.4285714285714287E-4, 500, 1500, "Forgot password page"], "isController": false}, {"data": [0.0, 500, 1500, "Tradiumpro Home Page-3"], "isController": false}, {"data": [0.6067868504772004, 500, 1500, "Forgot password page-0"], "isController": false}, {"data": [0.1494167550371156, 500, 1500, "Forgot password page-1"], "isController": false}, {"data": [7.142857142857143E-5, 500, 1500, "Security settings page"], "isController": false}, {"data": [1.8355359765051394E-4, 500, 1500, "Sign up page-2"], "isController": false}, {"data": [0.02702702702702703, 500, 1500, "Security settings page-3"], "isController": false}, {"data": [0.687360594795539, 500, 1500, "Sign up page-0"], "isController": false}, {"data": [0.18068679419221018, 500, 1500, "Security settings page-1"], "isController": false}, {"data": [7.142857142857143E-5, 500, 1500, "Sign up page"], "isController": false}, {"data": [0.13816604708798016, 500, 1500, "Sign up page-1"], "isController": false}, {"data": [9.721322099805574E-4, 500, 1500, "Security settings page-2"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 92824, 57338, 61.77066275963113, 3026.189584590202, 0, 51047, 1643.5, 8457.0, 10708.95, 21039.0, 399.8208163194983, 1102.5860221653659, 48.55480494122689], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Security settings page-0", 4339, 0, 0.0, 553.052777137589, 251, 15609, 521.0, 562.0, 604.0, 1556.6000000000004, 19.311566466682095, 7.430426941281978, 2.3573689534524043], "isController": false}, {"data": ["Log in page", 7000, 6983, 99.75714285714285, 3880.1994285714227, 0, 29865, 872.0, 12027.0, 14327.549999999988, 21047.0, 31.374658240329882, 94.34786057045851, 5.211156527329568], "isController": false}, {"data": ["Tradiumpro Home Page", 7000, 6776, 96.8, 5860.448142857151, 0, 25685, 1774.5, 15305.700000000023, 21035.0, 21628.97, 31.036623215394165, 257.4374539300124, 4.063043833688038], "isController": false}, {"data": ["Log in page-1", 5252, 2567, 48.87661843107388, 1151.0177075399865, 0, 21044, 549.0, 2657.7, 3010.3499999999995, 5513.920000000035, 23.777186215389072, 33.266524369125875, 1.4994790817804822], "isController": false}, {"data": ["Log in page-2", 2685, 2668, 99.36685288640597, 4931.522905027937, 0, 15075, 5090.0, 10126.4, 11143.8, 13899.0, 12.44046184925033, 36.61412567241044, 0.9531832422693071], "isController": false}, {"data": ["Log in page-0", 5252, 0, 0.0, 605.219535415079, 251, 15988, 527.0, 576.0, 662.3499999999995, 3537.9400000000005, 23.777724455471095, 9.079189709071484, 2.832892952702611], "isController": false}, {"data": ["Tradiumpro Home Page-0", 4605, 0, 0.0, 572.6010857763316, 251, 15621, 526.0, 566.0, 609.0, 1572.7599999999984, 20.44921666844293, 7.688426188818874, 2.3165128257220506], "isController": false}, {"data": ["Forgot password page-2", 3349, 3319, 99.10421021200358, 4597.656613914613, 1, 14534, 4267.0, 9977.0, 10800.5, 13555.0, 15.62995874325611, 46.11134442322232, 1.255605749866989], "isController": false}, {"data": ["Tradiumpro Home Page-1", 4605, 4345, 94.35396308360478, 7487.7018458197645, 0, 24899, 8532.0, 15662.800000000001, 20510.4, 21145.82, 20.467212458998908, 225.39175697463043, 1.7460882290194406], "isController": false}, {"data": ["Tradiumpro Home Page-2", 50, 36, 72.0, 1686.0599999999997, 1, 9861, 112.0, 5348.4, 9708.699999999999, 9861.0, 0.4316000276224018, 4.2861170321239905, 0.014869969701678061], "isController": false}, {"data": ["Forgot password page", 7000, 6970, 99.57142857142857, 4149.506857142864, 0, 27728, 1797.0, 12033.0, 13609.8, 21043.989999999998, 31.04446898435802, 94.09064894859036, 5.860427428287276], "isController": false}, {"data": ["Tradiumpro Home Page-3", 1, 0, 0.0, 3757.0, 3757, 3757, 3757.0, 3757.0, 3757.0, 3757.0, 0.26616981634282677, 8.29909169550173, 0.03639040457812084], "isController": false}, {"data": ["Forgot password page-0", 4715, 0, 0.0, 556.0209968186632, 250, 15589, 522.0, 569.0, 617.0, 1560.6800000000003, 21.202064896755164, 8.302761741795724, 2.7330786780973453], "isController": false}, {"data": ["Forgot password page-1", 4715, 1366, 28.97136797454931, 1493.0922587486732, 0, 18181, 1532.0, 2750.0, 3012.0, 5967.400000000005, 21.230323115161557, 20.867445245522045, 2.0018985998793273], "isController": false}, {"data": ["Security settings page", 7000, 6994, 99.91428571428571, 3966.3434285714297, 0, 51047, 1089.0, 12046.900000000001, 13648.199999999997, 21041.989999999998, 31.040339137876753, 89.9623987516795, 5.242426607612422], "isController": false}, {"data": ["Sign up page-2", 2724, 2697, 99.00881057268722, 5086.5825991189395, 0, 20210, 5391.5, 10167.5, 11096.5, 13918.5, 12.286319967525145, 37.20980179626539, 1.0077036162103647], "isController": false}, {"data": ["Security settings page-3", 37, 31, 83.78378378378379, 5312.5675675675675, 189, 10826, 5758.0, 9429.6, 9664.100000000002, 10826.0, 0.1995491268377396, 1.2046630366927698, 0.024448560145185472], "isController": false}, {"data": ["Sign up page-0", 4035, 0, 0.0, 500.4743494423786, 251, 15587, 511.0, 547.4000000000001, 584.0, 1557.9199999999996, 18.066948454346814, 6.933897209529587, 2.1877945393935594], "isController": false}, {"data": ["Security settings page-1", 4339, 1253, 28.877621571790737, 1428.7676884074651, 0, 21065, 1308.0, 2728.0, 3018.0, 4906.000000000018, 19.331269073979193, 18.24055420351518, 1.7229233031119822], "isController": false}, {"data": ["Sign up page", 7000, 6973, 99.61428571428571, 3633.0330000000035, 0, 28014, 777.0, 11908.800000000001, 13457.95, 21043.0, 31.22713727449546, 89.97729741812914, 4.700294064836459], "isController": false}, {"data": ["Sign up page-1", 4035, 1311, 32.4907063197026, 1446.740520446097, 0, 17631, 1387.0, 2855.0, 3228.3999999999987, 5402.359999999997, 18.09060095765858, 18.49204658750067, 1.5315608971772385], "isController": false}, {"data": ["Security settings page-2", 3086, 3049, 98.80103694102398, 4937.779001944262, 2, 15187, 4901.0, 10140.0, 10890.0, 12612.650000000001, 14.16310982605902, 39.91713224706274, 1.1993221923906559], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to tradiumpro.com:443 [tradiumpro.com/140.82.48.141] failed: Connection timed out: connect", 14, 0.024416617252084133, 0.015082306300094803], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: tradiumpro.com:80 failed to respond", 10264, 17.900868533956537, 11.057485133155218], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 1529, 2.6666434127454743, 1.6472033094889253], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: tradiumpro.com:443 failed to respond", 17600, 30.695175974048624, 18.960613634404897], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to tradiumpro.com:80 [tradiumpro.com/140.82.48.141] failed: Connection timed out: connect", 846, 1.4754612996616554, 0.9114022235628717], "isController": false}, {"data": ["500/Internal Server Error", 22720, 39.62468171195368, 24.47642850986814], "isController": false}, {"data": ["Non HTTP response code: javax.net.ssl.SSLHandshakeException/Non HTTP response message: Remote host terminated the handshake", 4364, 7.611008406292511, 4.701370335258123], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 1, 0.001744044089434581, 0.0010773075928639144], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 92824, 57338, "500/Internal Server Error", 22720, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: tradiumpro.com:443 failed to respond", 17600, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: tradiumpro.com:80 failed to respond", 10264, "Non HTTP response code: javax.net.ssl.SSLHandshakeException/Non HTTP response message: Remote host terminated the handshake", 4364, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 1529], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": ["Log in page", 7000, 6983, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: tradiumpro.com:443 failed to respond", 2932, "500/Internal Server Error", 1819, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: tradiumpro.com:80 failed to respond", 1328, "Non HTTP response code: javax.net.ssl.SSLHandshakeException/Non HTTP response message: Remote host terminated the handshake", 424, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 280], "isController": false}, {"data": ["Tradiumpro Home Page", 7000, 6776, "500/Internal Server Error", 3208, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: tradiumpro.com:80 failed to respond", 2026, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: tradiumpro.com:443 failed to respond", 593, "Non HTTP response code: javax.net.ssl.SSLHandshakeException/Non HTTP response message: Remote host terminated the handshake", 515, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 271], "isController": false}, {"data": ["Log in page-1", 5252, 2567, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: tradiumpro.com:443 failed to respond", 1990, "Non HTTP response code: javax.net.ssl.SSLHandshakeException/Non HTTP response message: Remote host terminated the handshake", 424, "500/Internal Server Error", 95, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 57, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to tradiumpro.com:443 [tradiumpro.com/140.82.48.141] failed: Connection timed out: connect", 1], "isController": false}, {"data": ["Log in page-2", 2685, 2668, "500/Internal Server Error", 1724, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: tradiumpro.com:443 failed to respond", 942, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 2, "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Forgot password page-2", 3349, 3319, "500/Internal Server Error", 2073, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: tradiumpro.com:443 failed to respond", 1245, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 1, "", "", "", ""], "isController": false}, {"data": ["Tradiumpro Home Page-1", 4605, 4345, "500/Internal Server Error", 3208, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: tradiumpro.com:443 failed to respond", 557, "Non HTTP response code: javax.net.ssl.SSLHandshakeException/Non HTTP response message: Remote host terminated the handshake", 515, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 62, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to tradiumpro.com:443 [tradiumpro.com/140.82.48.141] failed: Connection timed out: connect", 3], "isController": false}, {"data": ["Tradiumpro Home Page-2", 50, 36, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: tradiumpro.com:443 failed to respond", 36, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Forgot password page", 7000, 6970, "500/Internal Server Error", 2173, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: tradiumpro.com:80 failed to respond", 1938, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: tradiumpro.com:443 failed to respond", 1935, "Non HTTP response code: javax.net.ssl.SSLHandshakeException/Non HTTP response message: Remote host terminated the handshake", 521, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 232], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Forgot password page-1", 4715, 1366, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: tradiumpro.com:443 failed to respond", 690, "Non HTTP response code: javax.net.ssl.SSLHandshakeException/Non HTTP response message: Remote host terminated the handshake", 521, "500/Internal Server Error", 100, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 55, "", ""], "isController": false}, {"data": ["Security settings page", 7000, 6994, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: tradiumpro.com:80 failed to respond", 2355, "500/Internal Server Error", 2230, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: tradiumpro.com:443 failed to respond", 1683, "Non HTTP response code: javax.net.ssl.SSLHandshakeException/Non HTTP response message: Remote host terminated the handshake", 359, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 203], "isController": false}, {"data": ["Sign up page-2", 2724, 2697, "500/Internal Server Error", 1833, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: tradiumpro.com:443 failed to respond", 863, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 1, "", "", "", ""], "isController": false}, {"data": ["Security settings page-3", 37, 31, "500/Internal Server Error", 27, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: tradiumpro.com:443 failed to respond", 4, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["Security settings page-1", 4339, 1253, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: tradiumpro.com:443 failed to respond", 752, "Non HTTP response code: javax.net.ssl.SSLHandshakeException/Non HTTP response message: Remote host terminated the handshake", 359, "500/Internal Server Error", 82, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 57, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to tradiumpro.com:443 [tradiumpro.com/140.82.48.141] failed: Connection timed out: connect", 3], "isController": false}, {"data": ["Sign up page", 7000, 6973, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: tradiumpro.com:80 failed to respond", 2617, "500/Internal Server Error", 1930, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: tradiumpro.com:443 failed to respond", 1657, "Non HTTP response code: javax.net.ssl.SSLHandshakeException/Non HTTP response message: Remote host terminated the handshake", 363, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 250], "isController": false}, {"data": ["Sign up page-1", 4035, 1311, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: tradiumpro.com:443 failed to respond", 794, "Non HTTP response code: javax.net.ssl.SSLHandshakeException/Non HTTP response message: Remote host terminated the handshake", 363, "500/Internal Server Error", 97, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 57, "", ""], "isController": false}, {"data": ["Security settings page-2", 3086, 3049, "500/Internal Server Error", 2121, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: tradiumpro.com:443 failed to respond", 927, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 1, "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
